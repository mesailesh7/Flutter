package com.example.employee_profile

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
